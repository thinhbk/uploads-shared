define(['angular', './sample-module'], function(angular, module) {
    'use strict';

    /**
     * PredixAssetService is a sample service that integrates with Predix Asset Server API
     */
    module.factory('PredixTimeSeriesService', ['$q', '$http', '$rootScope', function($q, $http, $rootScope) {
        /**
         * Predix Asset server base url
         */
        var baseUrl = '/api/predix-timeseries';

        var getTimeSeriesById = function(id) {
            var deferred = $q.defer();

            var assetDetailsUrl = baseUrl + model + '?filter=id=' +id;

            $http.get(assetDetailsUrl)
            .then(function (res) {
                deferred.resolve(res.data);
            },
            function () {
                deferred.reject('Error fetching reasons');
            });

            return deferred.promise;
        };


        return {
            getAssetsByParentId: getAssetsByParentId,
            getDowntimeReasons: getDowntimeReasons,
            getAssetsById:getAssetsById,
            getSiteByLineId: getSiteByLineId
        };
    }]);
});
