define(['angular', './sample-module'], function(angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('ProductionLineCtrl', ['$scope', '$log', 'PredixAssetService', 'PredixViewService', '$state', '$http', 'LpmPerformanceService', '$interval', '$rootScope', '$stateParams', 'wcParetoService', 'LpmParetoStoppageService', 'LpmParetoWeeklyService',
        function($scope, $log, PredixAssetService, PredixViewService, $state, $http, LpmPerformanceService, $interval, $rootScope, $stateParams, wcParetoService, LpmParetoStoppageService, LpmParetoWeeklyService) {
            var self = this;
            var REFRESH_DATA_INTERVAL = 3000;
            var chartColors = ['#9d722a', '#059748', '#df5c24', '#3e87e8', '#88bde6'];

            
            $scope.$on('$destroy', function iVeBeenDismissed() {
               // say goodbye to your controller here
               $interval.cancel($scope.refreshPromiseTimer);
            });
        }]);
});
