define(['angular', './sample-module'], function(angular, module) {
    'use strict';

    /**
     * PredixAssetService is a sample service that integrates with Predix Asset Server API
     */
    module.factory('PredixAssetService', ['$q', '$http', '$rootScope', function($q, $http, $rootScope) {
        /**
         * Predix Asset server base url
         */
        var baseUrl = '/api/predix-asset/';
        var model = '/';

        /**
         * transform the asset entity into an object format consumable by px-context-browser item
         */
        var transformChildren = function(entities) { // transform your entity to context browser entity format
            var result = [];
            for (var i = 0; i < entities.length; i++) {
                var entity = entities[i];
                var staticLabels ={};
                var isOpenable;
                var isLast;
                if(entity.type == 'productionline' || entity.type == 'workcell') {
                    isOpenable = true;
                }else {
                    isOpenable = false;
                }
                if(entity.type == 'workcell' && entity.isLast) {
                    isLast = true;
                }else {
                    isLast = false;
                }
                var transformedEntity =  {
                    sequence: entity.sequence, // Display sequence
                    name: entity.description, // Displayed name in the context browser
                    id: entity.uri, // Unique ID (could be a URI for example)
                    identifier: entity.uri, // Unique ID (could be a URI for example)
                    parentId: entity.parent, // Parent ID. Used to place the children under the corresponding parent in the browser.
                    classification: entity.classification, // Classification used for fetching the views.
                    type: entity.type, // Classification used for fetching the views.
                    assetId: entity.id, // Classification used for fetching the views.
                    isOpenable: isOpenable,
                    level: entity.level
                };

                if (entity.downtimeReasons){
                    transformedEntity.downtimeReasons = entity.downtimeReasons;
                }

                if (entity.children){
                    transformedEntity.children = transformChildren(entity.children);
                }

                result.push(transformedEntity);
            }
            return result;
        };

        /**
         * fetch the asset children by parentId
         */
        var getEntityChildren = function(parentId, options) {
            var deferred = $q.defer();
            //var childrenUrl = baseUrl + '/sample-asset-'+parentId+'.json'; //'?pageSize=' + numberOfRecords + '&topLevelOnly=true&filter=parent=' + parentId;
            var childrenUrl = baseUrl + model +'' +parentId; //'?pageSize=' + numberOfRecords + '&topLevelOnly=true&filter=parent=' + parentId;
            var childEntities = {
                meta: {link: ''},
                data: []
            };
            if (options && options.hasOwnProperty('link')) {
                if (options.link === '') {
                    deferred.resolve(childEntities);
                    return deferred.promise;
                }
                else {
                    //overwrite url if there is link
                    childrenUrl = options.link;
                }
            }

            $http.get(childrenUrl)
                .success(function(data, status, headers) {
                    var linkHeader = headers('Link');
                    var link = '';
                    if (data.length !== 0) {
                        if (linkHeader && linkHeader !== '') {
                            var posOfGt = linkHeader.indexOf('>');
                            if (posOfGt !== -1) {
                                link = linkHeader.substring(1, posOfGt);
                            }
                        }
                    }

                    childEntities = {
                        meta: {link: link, parentId: parentId},
                        data: data
                    };
                    deferred.resolve(childEntities);
                })
                .error(function() {
                    deferred.reject('Error fetching asset with id ' + parentId);
                });


            return deferred.promise;
        };

        var getDowntimeReasons = function(id) {
            var deferred = $q.defer();
            //var childrenUrl = baseUrl + '/sample-asset-'+parentId+'.json'; //'?pageSize=' + numberOfRecords + '&topLevelOnly=true&filter=parent=' + parentId;
            var reasonLevelUrl = baseUrl + model +'?filter=id=' +id + '>parent[t1]&fields=downtimeReasons'; //'?pageSize=' + numberOfRecords + '&topLevelOnly=true&filter=parent=' + parentId;

            $http.get(reasonLevelUrl)
                .then(function (res) {
                    deferred.resolve(res.data[0].downtimeReasons);
                },
                function () {
                    deferred.reject('Error fetching reasons');
                });
            return deferred.promise;
        };

        /**
         * get asset by parent id
         */
        var getAssetsByParentId = function(parentId, options) {
            var deferred = $q.defer();

            getEntityChildren(parentId, options).then(function(results) {
                results.data = transformChildren(results.data);
                // Sort by sequence field
                results.data && results.data.sort(function(cell1,cell2){
                    return parseInt(cell1.sequence) - parseInt(cell2.sequence);
                });
                deferred.resolve(results);

            }, function() {
                deferred.reject('Error fetching asset with id ' + parentId);
            });

            return deferred.promise;
        };

        var getSiteByLineId = function(lineId){
            var deferred = $q.defer();
            var siteCond = baseUrl + model +'?filter=id=' +lineId + '>parent[t2]:type=site';
             $http.get(siteCond)
                .success(function(data, status, headers) {
                    deferred.resolve(data);
                });
            return deferred.promise;
        };

        var getAssetsById = function(id) {
            var deferred = $q.defer();

            var assetDetailsUrl = baseUrl + model + '?filter=id=' +id;

            $http.get(assetDetailsUrl)
            .then(function (res) {
                deferred.resolve(res.data);
            },
            function () {
                deferred.reject('Error fetching reasons');
            });

            return deferred.promise;
        };


        return {
            getAssetsByParentId: getAssetsByParentId,
            getDowntimeReasons: getDowntimeReasons,
            getAssetsById:getAssetsById,
            getSiteByLineId: getSiteByLineId
        };
    }]);
});
