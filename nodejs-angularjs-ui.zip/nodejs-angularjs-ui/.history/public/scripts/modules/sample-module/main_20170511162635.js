define(['./sample-module', './dashboard-controller',
    './predix-asset-service', './predix-user-service', './production-line-controller'], function() {

});
