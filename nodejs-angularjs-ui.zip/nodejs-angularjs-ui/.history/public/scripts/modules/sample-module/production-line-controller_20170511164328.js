define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('ProductionLineCtrl', ['$scope', '$log', 'PredixAssetService', '$state', '$http', '$interval', '$rootScope', '$stateParams', 'PredixTimeSeriesService',
        function ($scope, $log, PredixAssetService, $state, $http, $interval, $rootScope, $stateParams, PredixTimeSeriesService) {
            var self = this;
            var REFRESH_DATA_INTERVAL = 3000;
            var chartColors = ['#9d722a', '#059748', '#df5c24', '#3e87e8', '#88bde6'];

            // Init function
            (function () {
                var chartOptions = {
                    chart: {
                        animation: false,
                        type: 'column',
                        spacingBottom: 35,
                        renderTo: "chartContainer",
                        plotBackgroundColor: 'gray',
                        backgroundColor: 'black',
                        style: {
                            color: 'white'
                        }
                    },
                    title: {
                        text: '',
                        style: {
                            fontSize: '2em',
                            color: 'white'
                        }
                    },
                    exporting: { enabled: false },
                    credits: { enabled: false },
                    rangeSelector: { enabled: false },
                    xAxis: {
                        categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas'],
                        labels: {
                            style: {
                                color: 'white',
                                fontSize: '16px'
                            }
                        }
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Number',
                            style: {
                                color: 'white',
                                fontSize: '20px'
                            }
                        },
                        labels: {
                            style: {
                                color: 'white',
                                fontSize: '16px'
                            }
                        },
                        stackLabels: {
                            enabled: true,
                            style: {
                                fontWeight: 'bold',
                                color: (Highcharts.theme && Highcharts.theme.textColor) || 'white',
                                textShadow: '0 0 2px black',
                                fontSize: '16px'
                            }
                        },
                        gridLineWidth: 0
                    },
                    legend: {
                        enabled: false,
                        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                        borderColor: '#CCC',
                        borderWidth: 1,
                        fontSize: '16px'
                    },
                    tooltip: {
                        headerFormat: '<b>{point.x}</b><br/>',
                        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
                    },
                    plotOptions: {
                        series: {
                            animation: false
                        },
                        column: {
                            dataLabels: {
                                stacking: 'normal',
                                enabled: true,
                                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                                style: {
                                    textShadow: '0 0 2px black',
                                    fontSize: '16px'
                                }
                            },
                            borderWidth: 0,
                            animation: false
                        }
                    },
                    series: [{
                        name: 'John',
                        data: [5, 3, 4, 7, 2]
                    }, {
                        name: 'Jane',
                        data: [2, 2, 3, 2, 1]
                    }, {
                        name: 'Joe',
                        data: [3, 4, 4, 2, 5]
                    }]
                };
                new Highcharts.Chart(chartOptions);

                var seriesOptions = [];
                PredixTimeSeriesService.getTimeSeriesDataById('delta-egt').then(function (data) {
                    data.tags.array.forEach(function (element) {
                        seriesOptions.push({
                            name: element.name,
                            data: element.results[0].datapoints
                        });
                    }, this);

                    new Highcharts.stockChart('chartContainer2', {

                        rangeSelector: {
                            selected: 4
                        },

                        yAxis: {
                            labels: {
                                formatter: function () {
                                    return (this.value > 0 ? ' + ' : '') + this.value + '%';
                                }
                            },
                            plotLines: [{
                                value: 0,
                                width: 2,
                                color: 'silver'
                            }]
                        },

                        plotOptions: {
                            series: {
                                compare: 'percent',
                                showInNavigator: true
                            }
                        },

                        tooltip: {
                            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.change}%)<br/>',
                            valueDecimals: 2,
                            split: true
                        },

                        series: seriesOptions
                    });

                }());

                $scope.$on('$destroy', function iVeBeenDismissed() {
                    // say goodbye to your controller here
                    $interval.cancel($scope.refreshPromiseTimer);
                });
            }]);
});
