define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('ProductionLineCtrl', ['$scope', '$log', 'PredixAssetService', 'PredixViewService', '$state', '$http', 'LpmPerformanceService', '$interval', '$rootScope', '$stateParams', 'wcParetoService', 'LpmParetoStoppageService', 'LpmParetoWeeklyService',
        function ($scope, $log, PredixAssetService, PredixViewService, $state, $http, LpmPerformanceService, $interval, $rootScope, $stateParams, wcParetoService, LpmParetoStoppageService, LpmParetoWeeklyService) {
            var self = this;
            var REFRESH_DATA_INTERVAL = 3000;
            var chartColors = ['#9d722a', '#059748', '#df5c24', '#3e87e8', '#88bde6'];

            (function () {
                var chartOptions = {
                    chart: {
                        animation: false,
                        type: 'column',
                        spacingBottom: 35,
                        renderTo: "hcStoppageParetoContainer",
                        plotBackgroundColor: 'gray',
                        backgroundColor: 'black',
                        style: {
                            color: 'white'
                        }
                    },
                    title: {
                        text: '',
                        style: {
                            fontSize: '2em',
                            color: 'white'
                        }
                    },
                    exporting: { enabled: false },
                    credits: { enabled: false },
                    rangeSelector: { enabled: false },
                    xAxis: {
                        categories: [],
                        labels: {
                            style: {
                                color: 'white',
                                fontSize: '16px'
                            }
                        }
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Minutes',
                            style: {
                                color: 'white',
                                fontSize: '20px'
                            }
                        },
                        labels: {
                            style: {
                                color: 'white',
                                fontSize: '16px'
                            }
                        },
                        stackLabels: {
                            enabled: true,
                            style: {
                                fontWeight: 'bold',
                                color: (Highcharts.theme && Highcharts.theme.textColor) || 'white',
                                textShadow: '0 0 2px black',
                                fontSize: '16px'
                            },
                            formatter: function () {
                                return document._formatLostTime(Math.floor(this.total * 60));
                            }
                        },
                        gridLineWidth: 0
                    },
                    legend: {
                        enabled: false,
                        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                        borderColor: '#CCC',
                        borderWidth: 1,
                        fontSize: '16px'
                    },
                    tooltip: {
                        headerFormat: '<b>{point.x}</b><br/>',
                        formatter: function () {
                            return this.series.name + ': ' + document._formatLostTime(Math.floor(this.point.y * 60));
                        }
                    },
                    plotOptions: {
                        series: {
                            animation: false
                        },
                        column: {
                            dataLabels: {
                                stacking: 'normal',
                                enabled: true,
                                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                                style: {
                                    textShadow: '0 0 2px black',
                                    fontSize: '16px'
                                },
                                formatter: function () {
                                    if (this.y != 0 && this.y != this.total) {
                                        return document._formatLostTime(Math.floor(this.y * 60));
                                    }
                                }
                            },
                            borderWidth: 0,
                            animation: false
                        }
                    },
                    series: [[1, 2], [3, 4]]
                };
                new Highcharts.Chart('chartContainer', chartOptions);
            }());

            $scope.$on('$destroy', function iVeBeenDismissed() {
                // say goodbye to your controller here
                $interval.cancel($scope.refreshPromiseTimer);
            });
        }]);
});
