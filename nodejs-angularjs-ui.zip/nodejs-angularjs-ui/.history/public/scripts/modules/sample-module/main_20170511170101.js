define(['./sample-module', './dashboard-controller',
    './predix-asset-service', './predix-time-series-service', './predix-user-service', './asset-detail-controller'], function() {

});
