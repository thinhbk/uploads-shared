define(['./sample-module', './dashboard-controller',
    './predix-asset-service', './predix-time-series-service', './predix-user-service', './asset-controller'], function() {

});
