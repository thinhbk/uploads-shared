define(['./dashboard-controller',
    './predix-asset-service', './predix-user-service', './production-line-controller','./downtime-simulator-controller','./downtime-persistence-service','./wc-pareto-service','./lpm-pareto-stoppage-service','./lpm-pareto-weekly-service'], function() {

});
