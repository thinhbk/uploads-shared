define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('DashboardsCtrl', ['$scope', '$log', 'PredixAssetService', 'PredixViewService', '$state', '$http','LpmPerformanceService','$interval', '$rootScope','$location',
    function ($scope, $log, PredixAssetService, PredixViewService, $state, $http, LpmPerformanceService,$interval, $rootScope, $location) {
		var REFRESH_DATA_INTERVAL = 5000;
        var refreshPromise;

        PredixAssetService.getAssetsByParentId('root').then(function (initialContext) {

            //pre-select the 1st asset
            initialContext.data[0].selectedAsset = true;
            $scope.initialContexts = initialContext;
            $scope.initialContextName = initialContext.data[0].name;

            //load view selector
            $scope.openContext($scope.initialContexts.data[0]);
        }, function (message) {
            $log.error(message);
        });
        //VARIABLE TO CHANGE THE VIEW BETWEEN WORKCELL AND PRODUCTIONLINE
        $scope.viewSelector = '';
        //Intial variable declaration for productionLine
        $scope.cells = null;
        $scope.performance = null;
        $scope.divShow = " ";
        $scope.assetid = '';
        $scope.name = '';
        $scope.reasons = [];

        $scope.show = function(arg) {
            $scope.divShow = arg;
        }

        $rootScope.$on("CallOpenContext", function(event,data){
           $scope.openContext(data);
        });

        var downtimeEl = angular.element( document.querySelector( '#downtimeScreenWrapper' ) );
        var performanceEl = angular.element( document.querySelector( '#performanceScreenWrapper' ) );
        // callback for when the Open button is clicked
        $scope.openContext = function (contextDetails) {

            // need to clean up the context details so it doesn't have the infinite parent/children cycle,
            // which causes problems later (can't interpolate: {{context}} TypeError: Converting circular structure to JSON)
            var newContext = angular.copy(contextDetails);
            newContext.children = [];
            newContext.parent = [];

            $scope.context = newContext;
            $scope.reasons = [];

            if($scope.context.type == 'workcell') {
                $state.go('dashboard.downtime', {id: $scope.context.assetId, parentId: $scope.context.parentId, name: $scope.context.name, uri: $scope.context.id});
            }else if($scope.context.type == 'productionline') {
                $state.go('dashboard.performance', {sourceKey: $scope.context.id,parentId: $scope.context.parentId});
            }
        };

        $scope.getChildren = function (parent, options) {
            return PredixAssetService.getAssetsByParentId(parent.id, options || {});
        };

        $scope.handlers = {
            itemOpenHandler: $scope.openContext,
            getChildren: $scope.getChildren
            // (optional) click handler: itemClickHandler: $scope.clickHandler
        };
    }]);
});
