/*******************************************************
 The predix-seed Express web application includes these features:
 * routes to mock data files to demonstrate the UI
 * passport-predix-oauth for authentication, and a sample secure route
 * a proxy module for calling Predix services such as asset and time series
 *******************************************************/

var express = require('express');
var jsonServer = require('json-server'); // used for mock api responses
var path = require('path');
var cookieParser = require('cookie-parser'); // used for session cookie
var bodyParser = require('body-parser');
var passport;  // only used if you have configured properties for UAA
// simple in-memory session is used here. use connect-redis for production!!
var session = require('express-session');
var proxy = require('./proxy'); // used when requesting data from real services.
// get config settings from local file or VCAPS env var in the cloud
var config = require('./predix-config');
// configure passport for authentication with UAA
var passportConfig = require('./passport-config');

// if running locally, we need to set up the proxy from local config file:
var node_env = process.env.node_env || 'development';
if (node_env === 'development') {
    var devConfig = require('./localConfig.json')[node_env];
    proxy.setServiceConfig(config.buildVcapObjectFromLocalConfig(devConfig));
    proxy.setUaaConfig(devConfig);
}

var windServiceURL = devConfig ? devConfig.windServiceURL : process.env.windServiceURL;
var dataHandlerURL = devConfig ? devConfig.dataHandlerURL : process.env.dataHandlerURL;

console.log('************' + node_env + '******************');

var uaaIsConfigured = config.clientId &&
    config.uaaURL &&
    config.uaaURL.indexOf('https') === 0 &&
    config.base64ClientCredential;
if (uaaIsConfigured) {
    passport = passportConfig.configurePassportStrategy(config);
}

/**********************************************************************
 SETTING UP EXRESS SERVER
 ***********************************************************************/
var app = express();

app.set('trust proxy', 1);
app.use(cookieParser('predixsample'));
// Initializing default session store
// *** Use this in-memory session store for development only. Use redis for prod. **
app.use(session({
    secret: 'predixdojoadmin',
    name: 'predixdojoadmincookie',
    proxy: true,
    resave: true,
    saveUninitialized: true
}));

var server = app.listen(process.env.VCAP_APP_PORT || 5000, function () {
    console.log('Server started on port: ' + server.address().port);
});

var assetRoutes = require('./predix-asset-routes.js')();
var timeSeriesRoutes = require('./time-series-routes.js')();
app.use('/api/predix-asset', jsonServer.router(assetRoutes));
app.use('/api/predix-time-series', jsonServer.router(timeSeriesRoutes));

if (uaaIsConfigured) {
    app.use(passport.initialize());
    // Also use passport.session() middleware, to support persistent login sessions (recommended).
    app.use(passport.session());
}


//logout route
app.get('/logout', function (req, res) {
    req.session.destroy();
    if (req.session) {
        req.session.destroy();
    }
    req.logout();
    passportConfig.reset(); //reset auth tokens
    console.log(config.uaaURL + '/logout?redirect=' + config.logoutUrl);
    res.redirect(config.uaaURL + '/logout?redirect=' + config.logoutUrl);
});
var proxies = {
    proxy: {
        forward: {
            '/data-handler/(.*)': dataHandlerURL + '/$1'
        },
        headers: {
            'Content-Type': 'application/json',
            'Authorization': function (req) {
                return 'Bearer '.concat(req.session && req.session.passport && req.session.passport.user && req.session.passport.user.ticket ? req.session.passport.user.ticket.access_token : "");
            }
        }
    }
};
app.use(require('json-proxy').initialize(proxies));

//Initializing application modules
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

/****************************************************************************
 SET UP EXPRESS ROUTES
 *****************************************************************************/

if (!uaaIsConfigured) { // no restrictions
    app.use(express.static(path.join(__dirname, process.env['base-dir'] ? process.env['base-dir'] : '../public')));
} else {
    //login route redirect to predix uaa login page
    app.get('/login', passport.authenticate('predix', {'scope': ''}), function (req, res) {
        // The request will be redirected to Predix for authentication, so this
        // function will not be called.
    });
    app.get('/userinfo',
        passport.authenticate('main', {
            noredirect: true
        }),
        proxy.getUserInfo);
    // access real Predix services using this route.
    // the proxy will add UAA token and Predix Zone ID.
    app.use('/predix-api',
        passport.authenticate('main', {
            noredirect: true
        }),
        proxy.router);

    //callback route redirects to secure route after login
    app.get('/callback', passport.authenticate('predix', {
        failureRedirect: '/'
    }), function (req, res) {
        console.log('Redirecting to secure route...');
        res.redirect('/');
    });

    // example of calling a custom microservice.
    if (windServiceURL && windServiceURL.indexOf('https') === 0) {
        app.get('/windy/*', passport.authenticate('main', {noredirect: true}),
            // if calling a secure microservice, you can use this middleware to add a client token.
            // proxy.addClientTokenMiddleware,
            proxy.customProxyMiddleware('/windy', windServiceURL)
        );
    }


    //Or you can follow this pattern to create secure routes,
    // if only some portions of the app are secure.
    app.get('/secure', passport.authenticate('main', {
        noredirect: true //Don't redirect a user to the authentication page, just show an error
    }), function (req, res) {
        console.log('Accessing the secure route');
        // modify this to send a secure.html file if desired.
        res.send('<h2>This is a sample secure route.</h2>');
    });


    //Use this route to make the entire app secure.  This forces login for any path in the entire app.
    app.use('/bower_components',
        express.static(path.join(__dirname, '../public/bower_components'))
    );
    app.use('/elements',
        express.static(path.join(__dirname, '../public/elements'))
    );
    app.use('/', function (req, res, next) {
            if (req.path != '/page401.html') {
                if (req.session.passport && req.session.passport.user.scope && (req.session.passport.user.scope.indexOf('dojo.onboarding.admin') >= 0 || req.session.passport.user.scope.indexOf('dojo.onboarding.sensei') >= 0)) {
                    next();
                } else {
                    res.redirect('/page401.html');
                }
                // next();
            } else {
                next();
            }
        }, passport.authenticate('main', {
            noredirect: false //Don't redirect a user to the authentication page, just show an error
        }),
        express.static(path.join(__dirname, process.env['base-dir'] ? process.env['base-dir'] : '../public'))
    );


}

app.get('/favicon.ico', function (req, res) {
    res.send('favicon.ico');
});

// Sample route middleware to ensure user is authenticated.
//   Use this route middleware on any resource that needs to be protected.  If
//   the request is authenticated (typically via a persistent login session),
//   the request will proceed.  Otherwise, the user will be redirected to the
//   login page.
//currently not being used as we are using passport-oauth2-middleware to check if
//token has expired
/*
 function ensureAuthenticated(req, res, next) {
 if(req.isAuthenticated()) {
 return next();
 }
 res.redirect('/');
 }
 */

////// error handlers //////
// catch 404 and forward to error handler
app.use(function (err, req, res, next) {
    console.error(err.stack);
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// development error handler - prints stacktrace
if (node_env === 'development') {
    app.use(function (err, req, res, next) {
        if (!res.headersSent) {
            res.status(err.status || 500);
            res.send({
                message: err.message,
                error: err
            });
        }
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    if (!res.headersSent) {
        res.status(err.status || 500);
        res.send({
            message: err.message,
            error: err
        });
    }
});
module.exports = app;
