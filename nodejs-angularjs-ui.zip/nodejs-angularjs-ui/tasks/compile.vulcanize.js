'use strict';

// -------------------------------------------
//   Task: Compile: Vulcanize seed-app element
// -------------------------------------------

const vulcanize = require('gulp-vulcanize');

module.exports = function (gulp) {
    return function () {
        return gulp.src([
            'public/elements/seed-app/seed-app.html',
            'public/element/views/comment-view.html',
            'public/element/views/program-detail-view.html',
            'public/element/views/program-view.html',
            'public/element/views/projects-view.html',
            'public/element/views/questionnaire-review-view.html',
            'public/element/views/sensei-view.html',
            'public/element/views/sensei/sensei-editor.html',
            'public/element/views/sensei/sensei-form.html',
            'public/element/views/sensei/sensei-remover.html',
            'public/element/views/questionnaire/business-detail-modal.html',
            'public/element/views/questionnaire/detail-data-modal.html',
            'public/element/views/questionnaire/project-detail-modal.html',
            'public/element/views/questionnaire/project-overview-modal.html',
            'public/element/views/questionnaire/sensei-team/sensei-team-remover.html',
            'public/element/views/questionnaire/sensei-team/sensei-team-view.html',
            'public/element/views/questionnaire/team-requirements/participant-editor.html',
            'public/element/views/questionnaire/team-requirements/participant-remover.html',
            'public/element/views/questionnaire/team-requirements/team-member-form.html',
            'public/element/views/questionnaire/team-requirements/team-requirement-view.html'
        ], {base: 'public/elements/'})
            .pipe(vulcanize({
                abspath: '',
                excludes: [
                    'public/bower_components/polymer/polymer.html',
                    'public/bower_components/px-tooltip/px-tooltip.html',
                    'public/bower_components/px-view/px-view.html',
                    'public/bower_components/iron-meta/iron-meta.html',
                    'public/bower_components/iron-iconset-svg/iron-iconset-svg.html',
                    'public/bower_components/iron-icon/iron-icon.html',
                    'public/bower_components/iron-ajax/iron-ajax.html',
                    'public/bower_components/iron-ajax/iron-request.html',
                    'public/bower_components/px-card/px-card-header.html',
                    'public/bower_components/px-card/px-card.html'
                ],
                stripComments: true,
                inlineCSS: true,
                inlineScripts: true
            }))
            .pipe(gulp.dest('dist/public/elements/'));
    };
};
