/**
 * 
 */
package com.thinhpl.timeseries.dto;

/**
 * @author ThinhPL
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({ "start", "end", "tags" })

public class QueryDto {

	@JsonProperty("start")
	private long start;
	@JsonProperty("end")
	private long end;
	@JsonProperty("limit")
	private int limit;
	@JsonProperty("tags")
	private List<Tag> tags = new ArrayList<Tag>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The start
	 */
	@JsonProperty("start")
	public long getStart() {
		return start;
	}

	/**
	 * 
	 * @param start
	 *            The start
	 */
	@JsonProperty("start")
	public void setStart(long start) {
		this.start = start;
	}

	/**
	 * 
	 * @return The end
	 */
	@JsonProperty("end")
	public long getEnd() {
		return end;
	}

	/**
	 * 
	 * @param end
	 *            The end
	 */
	@JsonProperty("end")
	public void setEnd(long end) {
		this.end = end;
	}

	/**
	 * 
	 * @return The tags
	 */
	@JsonProperty("tags")
	public List<Tag> getTags() {
		return tags;
	}

	/**
	 * 
	 * @param tags
	 *            The tags
	 */
	@JsonProperty("tags")
	public void setTags(List<Tag> tags) {
		this.tags = tags;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	/**
	 * @return the limit
	 */
	@JsonProperty("limit")
	public int getLimit() {
		return limit;
	}

	/**
	 * @param limit the limit to set
	 */
	@JsonProperty("limit")
	public void setLimit(int limit) {
		this.limit = limit;
	}
}
