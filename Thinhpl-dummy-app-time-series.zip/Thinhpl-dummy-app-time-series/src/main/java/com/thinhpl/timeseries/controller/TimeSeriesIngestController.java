/**
 * 
 */
package com.thinhpl.timeseries.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.thinhpl.TmsConfig;
import com.thinhpl.timeseries.service.Body;
import com.thinhpl.timeseries.service.IngestPayloadDto;
import com.thinhpl.timeseries.service.TimeSeriesService;

/**
 * @author ThinhPL
 *
 */
@RestController
@RequestMapping(path = "/timeseriesingest")
public class TimeSeriesIngestController {

	@Autowired
	private TmsConfig tmsConfig;

	@Autowired
	private TimeSeriesService assetsService;
	
	@RequestMapping(path = "/datapoints", method = RequestMethod.POST)
	public boolean createTimeSeriesDataPoints(
			@RequestParam(defaultValue = "ALT_SENSOR", name = "tags", required = false) String[] tagNames,
			@RequestParam(defaultValue = "100", name = "counter", required = false) int counter) {
		boolean isSuccess = true;
		for(String tagName : tagNames){
			IngestPayloadDto payload = new IngestPayloadDto();		
			List<Body> bodies = new ArrayList<Body>();
			Body body = new Body();
			body.setName(tagName);
			List<List<Long>> datapoints = new ArrayList<List<Long>>();
			Calendar cal = Calendar.getInstance();
			Random randomMeasure = new Random(1000);
			Random randomQuality = new Random(3);
			for(int i = 0; i < counter ; i++){
				cal.add(Calendar.MILLISECOND, i);
				List<Long> datapoint = Arrays.asList(new Long[]{cal.getTimeInMillis(),new Long(randomMeasure.nextInt(1000)),new Long(randomQuality.nextInt(3))});
				datapoints.add(datapoint);
			}
			body.setDatapoints(datapoints);
			Map<String, String> attributes = new HashMap<String, String>();
			attributes.put("host", "server1");
			attributes.put("customer", "Acme");
			body.setAttributes(attributes);
			bodies.add(body);
			payload.setBody(bodies );
			payload.setMessageId(String.valueOf(System.currentTimeMillis()));
			String url = tmsConfig.getIngest_uri();
			if(!assetsService.createTimeSeriesDataPoints(url, payload)){
				isSuccess = false;
			}
		}
		return isSuccess;
	}
}
