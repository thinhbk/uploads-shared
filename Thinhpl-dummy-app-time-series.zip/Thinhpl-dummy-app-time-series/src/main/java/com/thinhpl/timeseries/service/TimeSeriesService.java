package com.thinhpl.timeseries.service;

import com.thinhpl.timeseries.dto.QueryDto;
import com.thinhpl.timeseries.dto.TagsResultDto;
import com.thinhpl.timeseries.dto.TimeSeriesDto;
import com.thinhpl.timeseries.latest.dto.TagsDto;

/**
 * The Interface TimeSeriesService.
 */
public interface TimeSeriesService {

	/**
	 * Gets the time series.
	 *
	 * @param url the url
	 * @param data the data
	 * @return the time series
	 */
	public TimeSeriesDto getTimeSeries(String url, QueryDto data);
	
	/**
	 * Creates the time series.
	 *
	 * @param url the url
	 * @param tags the tags to query
	 * @return TimeSeriesDto, if successful
	 */
	public TimeSeriesDto getLatestTimeSeries(String url, TagsDto tags);
	

	/**
	 * Gets the time series tags.
	 *
	 * @param url the url
	 * @return the time series tags
	 */
	public TagsResultDto getTimeSeriesTags(String url);
	
	/**
	 * Creates the time series data points.
	 *
	 * @param payload the data
	 * @return true, if successful
	 */
	public boolean createTimeSeriesDataPoints(String url, IngestPayloadDto payload);
}
