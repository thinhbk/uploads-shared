/**
 * 
 */
/**
 * @author ThinhPL
 *
 */
package com.thinhpl.timeseries.latest.dto;