/**
 * 
 */
package com.thinhpl.timeseries.service;

/**
 * @author ThinhPL
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * The Class IngestPayloadDto.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({ "messageId", "body" })
public class IngestPayloadDto {

	/** The message id. */
	@JsonProperty("messageId")
	private String messageId;
	
	/** The body. */
	@JsonProperty("body")
	private List<Body> body = new ArrayList<Body>();
	
	/** The additional properties. */
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * Gets the message id.
	 *
	 * @return The messageId
	 */
	@JsonProperty("messageId")
	public String getMessageId() {
		return messageId;
	}

	/**
	 * Sets the message id.
	 *
	 * @param messageId            The messageId
	 */
	@JsonProperty("messageId")
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	/**
	 * Gets the body.
	 *
	 * @return The body
	 */
	@JsonProperty("body")
	public List<Body> getBody() {
		return body;
	}

	/**
	 * Sets the body.
	 *
	 * @param body            The body
	 */
	@JsonProperty("body")
	public void setBody(List<Body> body) {
		this.body = body;
	}

	/**
	 * Gets the additional properties.
	 *
	 * @return the additional properties
	 */
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	/**
	 * Sets the additional property.
	 *
	 * @param name the name
	 * @param value the value
	 */
	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
