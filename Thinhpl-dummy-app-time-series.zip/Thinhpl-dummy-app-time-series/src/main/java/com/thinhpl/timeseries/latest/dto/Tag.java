/**
 * 
 */
package com.thinhpl.timeseries.latest.dto;

/**
 * @author ThinhPL
 *
 */
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.thinhpl.timeseries.dto.Filters;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({ "name", "filters" })
public class Tag {

	@JsonProperty("name")
	private String name;
	@JsonProperty("order")
	private String order;
	@JsonProperty("filters")
	private Filters filters;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The name
	 */
	@JsonProperty("name")
	public String getName() {
		return name;
	}

	/**
	 * 
	 * @param name
	 *            The name
	 */
	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * @return The filters
	 */
	@JsonProperty("filters")
	public Filters getFilters() {
		return filters;
	}

	/**
	 * 
	 * @param filters
	 *            The filters
	 */
	@JsonProperty("filters")
	public void setFilters(Filters filters) {
		this.filters = filters;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	/**
	 * @return the order
	 */
	@JsonProperty("order")
	public String getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	@JsonProperty("order")
	public void setOrder(String order) {
		this.order = order;
	}

}