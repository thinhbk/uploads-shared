/**
 * 
 */
package com.thinhpl.timeseries.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.thinhpl.TmsConfig;
import com.thinhpl.timeseries.dto.Attributes;
import com.thinhpl.timeseries.dto.Filters;
import com.thinhpl.timeseries.dto.Measurements;
import com.thinhpl.timeseries.dto.Qualities;
import com.thinhpl.timeseries.dto.QueryDto;
import com.thinhpl.timeseries.dto.Tag;
import com.thinhpl.timeseries.dto.TagsResultDto;
import com.thinhpl.timeseries.dto.TimeSeriesDto;
import com.thinhpl.timeseries.latest.dto.TagsDto;
import com.thinhpl.timeseries.service.TimeSeriesService;

/**
 * @author ThinhPL
 * 
 */
@RestController
@RequestMapping(path = "/timeseries")
public class TimeSeriesQueryController {

	@Autowired
	private TmsConfig tmsConfig;

	@Autowired
	private TimeSeriesService timeSeriesService;

	@RequestMapping(path = "/datapoints")
	public TimeSeriesDto getTimeSeriesDataPoints(@RequestParam(defaultValue = "ALT_SENSOR", name = "tag", required = false) String tagName,
			@RequestParam(defaultValue = "20", name = "limit", required = false) Integer limit) {
		QueryDto query = new QueryDto();
		query.setLimit(limit);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		query.setStart(cal.getTime().getTime());
		cal.add(Calendar.MONTH, 1);
		query.setEnd(cal.getTime().getTime());
		List<Tag> tags = new ArrayList<Tag>();
		Tag tag = new Tag();
		tag.setName(tagName);
		tag.setOrder("desc");
		tags.add(tag);
		query.setTags(tags);
		// ObjectMapper objectMapper = new ObjectMapper();
		// objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		// String writeValueAsString = objectMapper.writeValueAsString(query);
		String url = tmsConfig.getQuery_uri();
		return timeSeriesService.getTimeSeries(url + "/datapoints", query);
	}

	@RequestMapping(path = "/datapoints/latest")
	public TimeSeriesDto getLatestTimeSeriesDataPoints(
			@RequestParam(defaultValue = "ALT_SENSOR", name = "tag", required = false) String tagName) {
		// Calendar cal = Calendar.getInstance();
		// cal.add(Calendar.MONTH, -1);
		// query.setStart(cal.getTime().getTime());
		// cal.add(Calendar.MONTH, 1);
		// query.setEnd(cal.getTime().getTime());
		List<com.thinhpl.timeseries.latest.dto.Tag> tags = new ArrayList<com.thinhpl.timeseries.latest.dto.Tag>();
		com.thinhpl.timeseries.latest.dto.Tag tag = new com.thinhpl.timeseries.latest.dto.Tag();
		tag.setName(tagName);
		tag.setOrder("desc");
		Filters filters = new Filters();
		Attributes attributes = new Attributes();
		attributes.setHost(Arrays.asList(new String[] { "server1" }));
		filters.setAttributes(attributes);
		Measurements measurements = new Measurements();
		measurements.setValues(Arrays.asList(new Integer[] { 36 }));
		measurements.setCondition("le");
		filters.setMeasurements(measurements);
		Qualities qualities = new Qualities();
		qualities.setValues(Arrays.asList(new String[] { "3" }));
		filters.setQualities(qualities);
		tag.setFilters(filters);
		tags.add(tag);
		TagsDto tagDto = new TagsDto();
		tagDto.setTags(tags);
//		ObjectMapper objectMapper = new ObjectMapper();
//		objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
//		String writeValueAsString = objectMapper.writeValueAsString(tagDto);
		String url = tmsConfig.getQuery_uri();
		return timeSeriesService.getLatestTimeSeries(url + "/datapoints/latest",
				tagDto);
	}

	@RequestMapping(path = "/tags")
	public TagsResultDto getTimeSeriesTags() {
		String url = tmsConfig.getQuery_uri();
		return timeSeriesService.getTimeSeriesTags(url + "/tags");
	}
	//
	// private List<LocomotiveDto> createDummyData() {
	// List<LocomotiveDto> result = new ArrayList<LocomotiveDto>();
	// for (int i = 0; i < 10; i++) {
	// LocomotiveDto dto = new LocomotiveDto();
	// setDummyAssetsDto(dto, i);
	// result.add(dto);
	// }
	// return result;
	// }
	//
	// private void setDummyAssetsDto(Object dto, int i) {
	// Field[] fields = dto.getClass().getDeclaredFields();
	// for (Field field : fields) {
	// field.setAccessible(true);
	// if (field.getType() == String.class) {
	// try {
	// Method method = dto.getClass().getMethod(
	// "set" + field.getName().substring(0, 1).toUpperCase()
	// + field.getName().substring(1),String.class);
	// method.invoke(dto, field.getName() + " " + i);
	// } catch (NoSuchMethodException e) {
	// e.printStackTrace();
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	//
	// else if (field.getType() == Boolean.class || field.getType() ==
	// boolean.class) {
	// try {
	// Method method = dto.getClass().getMethod(
	// "set" + field.getName().substring(0, 1).toUpperCase()
	// + field.getName().substring(1),field.getType());
	// method.invoke(dto, true);
	// } catch (NoSuchMethodException e) {
	// e.printStackTrace();
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	// else if (field.getType() == List.class) {
	// try {
	// Type genericType = field.getGenericType();
	// if(genericType instanceof ParameterizedType){
	// ParameterizedType pType = (ParameterizedType)genericType;
	// if(pType.getActualTypeArguments()[0] == String.class){
	// Method method = dto.getClass().getMethod(
	// "set" + field.getName().substring(0, 1).toUpperCase()
	// + field.getName().substring(1), List.class);
	// List<String> value = new ArrayList<String>();
	// value.add(field.getName() + " " + i);
	// method.invoke(dto, value);
	// }
	// }
	// } catch (NoSuchMethodException e) {
	// e.printStackTrace();
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	// }
	// }
}
