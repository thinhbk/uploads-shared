package com.thinhpl.timeseries.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestOperations;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.predix.iot.wts.common.constants.Constants;
import com.predix.iot.wts.common.utils.UaaUtils;
import com.thinhpl.TmsConfig;
import com.thinhpl.UaaConfig;
import com.thinhpl.timeseries.dto.QueryDto;
import com.thinhpl.timeseries.dto.TagsResultDto;
import com.thinhpl.timeseries.dto.TimeSeriesDto;
import com.thinhpl.timeseries.latest.dto.TagsDto;
import com.thinhpl.websocket.client.TimeSeriesWebSocketClient;

/**
 * The Class TimeSeriesServiceImpl.
 */
@Component
public class TimeSeriesServiceImpl implements TimeSeriesService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(TimeSeriesServiceImpl.class);
	
	/** The uaa config. */
	@Autowired
	private UaaConfig uaaConfig;

	/** The ast config. */
	@Autowired
	private TmsConfig astConfig;
	
	/** The rest template. */
	@Autowired
	RestOperations restTemplate;

	/** The web socket client. */
	@Autowired
	TimeSeriesWebSocketClient webSocketClient;

	/** The token. */
	private String token;


	/* (non-Javadoc)
	 * @see com.thinhpl.timeseries.service.TimeSeriesService#getTimeSeries(java.lang.String, com.thinhpl.timeseries.dto.QueryDto)
	 */
	public TimeSeriesDto getTimeSeries(String url, QueryDto data) {
		HttpHeaders headers = setupHeader();
		HttpEntity<?> httpEntity = new HttpEntity<Object>(data, headers);	
		try {
			ResponseEntity<TimeSeriesDto> response = restTemplate.exchange(
					url, HttpMethod.POST, httpEntity, TimeSeriesDto.class);
			logger.info("Number of time series data points getting from WTS: "
					+ (response.getBody() == null ? 0
							: response.getBody().getTags().size()));
			return response.getBody();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.thinhpl.timeseries.service.TimeSeriesService#getLatestTimeSeries(java.lang.String, com.thinhpl.timeseries.latest.dto.TagsDto)
	 */
	public TimeSeriesDto getLatestTimeSeries(String url, TagsDto tags) {
		HttpHeaders headers = setupHeader();
		HttpEntity<?> httpEntity = new HttpEntity<Object>(tags, headers);	
		try {
			ResponseEntity<TimeSeriesDto> response = restTemplate.exchange(
					url, HttpMethod.POST, httpEntity, TimeSeriesDto.class);
			logger.info("Number of time series data points getting from WTS: "
					+ (response.getBody() == null ? 0
							: response.getBody().getTags().size()));
			return response.getBody();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.thinhpl.timeseries.service.TimeSeriesService#getTimeSeriesTags(java.lang.String)
	 */
	public TagsResultDto getTimeSeriesTags(String url) {
		HttpHeaders headers = setupHeader();
		HttpEntity<?> httpEntity = new HttpEntity<Object>(headers);	
		try {
			ResponseEntity<TagsResultDto> response = restTemplate.exchange(
					url, HttpMethod.GET, httpEntity, TagsResultDto.class);
			logger.info("Number of time series data points getting from WTS: "
					+ (response.getBody() == null ? 0
							: response.getBody().getResults().size()));
			return response.getBody();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}	

	/* (non-Javadoc)
	 * @see com.thinhpl.timeseries.service.TimeSeriesService#createTimeSeriesDataPoints(java.lang.String, com.thinhpl.timeseries.service.IngestPayloadDto)
	 */
	public boolean createTimeSeriesDataPoints(String url, IngestPayloadDto data) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			String writeValueAsString = objectMapper.writeValueAsString(data);
			// TODO: remove
			System.out.println(writeValueAsString);
			return webSocketClient.sendDataViaWebSocket(url, writeValueAsString);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Setup header.
	 *
	 * @return the http headers
	 */
	private HttpHeaders setupHeader() {
		String uri = uaaConfig.getUri();
		String token = getToken(uri);
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.TS_AUTHORIZATION, Constants.TOKEN_BEARER + token);
		headers.add(Constants.TS_CONTENT_TYPE, "application/json");
		headers.add(Constants.TS_PREDIX_ZONE_ID, astConfig.getInstanceId());
		return headers;
	}

	/**
	 * Gets the token.
	 *
	 * @param url the url
	 * @return the token
	 */
	private String getToken(String url) {
		if (token == null
				|| "" == token
				|| !UaaUtils.isTokenValid(uaaConfig.getUri(),
						uaaConfig.getClientBase64Token(), token)) {
			token = UaaUtils.getAdminAccessToken(uaaConfig.getUri(),
					uaaConfig.getClientBase64Token());
		}
		return token;
	}

}
