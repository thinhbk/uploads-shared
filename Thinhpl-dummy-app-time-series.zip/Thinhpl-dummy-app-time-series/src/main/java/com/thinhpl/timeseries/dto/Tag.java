/**
 * 
 */
package com.thinhpl.timeseries.dto;

/**
 * @author ThinhPL
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({ "name", "results", "stats" })
public class Tag {

	@JsonProperty("name")
	private String name;
	@JsonProperty("results")
	private List<TmsResult> results = new ArrayList<TmsResult>();
	@JsonProperty("stats")
	private Stats stats;
	@JsonProperty("order")
	private String order;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The name
	 */
	@JsonProperty("name")
	public String getName() {
		return name;
	}

	/**
	 * 
	 * @param name
	 *            The name
	 */
	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * @return The results
	 */
	@JsonProperty("results")
	public List<TmsResult> getResults() {
		return results;
	}

	/**
	 * 
	 * @param results
	 *            The results
	 */
	@JsonProperty("results")
	public void setResults(List<TmsResult> results) {
		this.results = results;
	}

	/**
	 * 
	 * @return The stats
	 */
	@JsonProperty("stats")
	public Stats getStats() {
		return stats;
	}

	/**
	 * 
	 * @param stats
	 *            The stats
	 */
	@JsonProperty("stats")
	public void setStats(Stats stats) {
		this.stats = stats;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	/**
	 * @return the order
	 */
	@JsonProperty("order")
	public String getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	@JsonProperty("order")
	public void setOrder(String order) {
		this.order = order;
	}

}