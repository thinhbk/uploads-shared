/**
 * 
 */
package com.thinhpl.timeseries.dto;

/**
 * @author ThinhPL
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({ "filters", "attributes", "values" })
public class TmsResult {

	@JsonProperty("filters")
	private Filters filters;
	@JsonProperty("attributes")
	private Attributes_ attributes;
	@JsonProperty("values")
	private List<List<Long>> values;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The filters
	 */
	@JsonProperty("filters")
	public Filters getFilters() {
		return filters;
	}

	/**
	 * 
	 * @param filters
	 *            The filters
	 */
	@JsonProperty("filters")
	public void setFilters(Filters filters) {
		this.filters = filters;
	}

	/**
	 * 
	 * @return The attributes
	 */
	@JsonProperty("attributes")
	public Attributes_ getAttributes() {
		return attributes;
	}

	/**
	 * 
	 * @param attributes
	 *            The attributes
	 */
	@JsonProperty("attributes")
	public void setAttributes(Attributes_ attributes) {
		this.attributes = attributes;
	}

	/**
	 * 
	 * @return The values
	 */
	@JsonProperty("values")
	public List<List<Long>> getValues() {
		return values;
	}

	/**
	 * 
	 * @param values
	 *            The values
	 */
	@JsonProperty("values")
	public void setValues(List<List<Long>> values) {
		this.values = values;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
