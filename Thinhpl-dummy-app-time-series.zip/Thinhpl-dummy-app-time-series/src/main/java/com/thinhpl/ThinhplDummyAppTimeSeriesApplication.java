package com.thinhpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.thinhpl","com.thinhpl.timeseries.controller","com.thinhpl.timeseries.service","com.thinhpl.websocket.client"})
public class ThinhplDummyAppTimeSeriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThinhplDummyAppTimeSeriesApplication.class, args);
	}
}
