/**
 * 
 */
package com.thinhpl;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class UaaConfig.
 *
 * @author ThinhPL
 */
@Configuration
@ConfigurationProperties(prefix = "uaa")
@EnableConfigurationProperties
public class UaaConfig {
	
	/** The client id. */
	private String clientId;
	
	/** The client secret. */
	private String clientSecret;
	
	/** The uri. */
	private String uri;
	
	/** The client base64 token. */
	private String clientBase64Token;
	
	/** The instance id. */
	private String instanceId;
	
	/** The name. */
	private String name;
	
	/**
	 * Gets the client id.
	 *
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	
	/**
	 * Sets the client id.
	 *
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	/**
	 * Gets the client secret.
	 *
	 * @return the clientSecret
	 */
	public String getClientSecret() {
		return clientSecret;
	}
	
	/**
	 * Sets the client secret.
	 *
	 * @param clientSecret the clientSecret to set
	 */
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
	
	/**
	 * Gets the client base64 token.
	 *
	 * @return the clientBase64Token
	 */
	public String getClientBase64Token() {
		return clientBase64Token;
	}
	
	/**
	 * Sets the client base64 token.
	 *
	 * @param clientBase64Token the clientBase64Token to set
	 */
	public void setClientBase64Token(String clientBase64Token) {
		this.clientBase64Token = clientBase64Token;
	}
	
	/**
	 * Gets the uri.
	 *
	 * @return the uri
	 */
	public String getUri() {
		return uri;
	}
	
	/**
	 * Sets the uri.
	 *
	 * @param uri the uri to set
	 */
	public void setUri(String uri) {
		this.uri = uri;
	}
	
	/**
	 * Gets the instance id.
	 *
	 * @return the instanceId
	 */
	public String getInstanceId() {
		return instanceId;
	}
	
	/**
	 * Sets the instance id.
	 *
	 * @param instanceId the instanceId to set
	 */
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Rest template.
	 *
	 * @return the rest template
	 */
	@Bean
	public RestOperations restOperations() {
	    RestTemplate rest = new RestTemplate();
	    //this is crucial!
	    rest.getMessageConverters().add(0, mappingJacksonHttpMessageConverter());
	    return rest;
	}

	@Bean
	public MappingJackson2HttpMessageConverter mappingJacksonHttpMessageConverter() {
	    MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
	    converter.setObjectMapper(objectMapper());
	    return converter;
	}
	
	@Bean
	public ObjectMapper objectMapper() {
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
	    objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
	    return objectMapper;
	}
}
