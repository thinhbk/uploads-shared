/**
 * 
 */
package com.thinhpl.websocket.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.websocket.ClientEndpointConfig;
import javax.websocket.Decoder;
import javax.websocket.Encoder;
import javax.websocket.Extension;
import javax.websocket.HandshakeResponse;

import org.apache.http.Header;

/**
 * The Class TimeSeriesClientEndpointConfig.
 *
 * @author ThinhPL
 */
public class TimeSeriesClientEndpointConfig extends
		ClientEndpointConfig.Configurator implements ClientEndpointConfig {

	/** The payload. */
	private String payload;
	
	/** The time. */
	private long time;
    
    /** The auth headers. */
    private List<Header> authHeaders;
	
    /**
     * Instantiates a new time series client endpoint config.
     *
     * @param payload the payload
     * @param time the time
     * @param authHeaders the auth headers
     */
    public TimeSeriesClientEndpointConfig(String payload, long time, List<Header> authHeaders){
    	this.payload = payload;
    	this.setTime(time);
    	this.authHeaders = authHeaders;
    }
    
    /* (non-Javadoc)
     * @see javax.websocket.ClientEndpointConfig.Configurator#beforeRequest(java.util.Map)
     */
    @Override
    public void beforeRequest(Map<String, List<String>> headers)
    {
        super.beforeRequest(headers);

        for (Header header : this.authHeaders)
        {
            List<String> attribList = new ArrayList<String>();
            attribList.add(header.getValue());
            headers.put(header.getName(), attribList);
        }
    }

    /*
     * (non-Javadoc)
     * @see
     * javax.websocket.ClientEndpointConfig.Configurator#afterResponse(javax
     * .websocket.HandshakeResponse)
     */
    @Override
    public void afterResponse(HandshakeResponse handshakeResponse)
    {
        super.afterResponse(handshakeResponse);
    }
    
	/* (non-Javadoc)
	 * @see javax.websocket.EndpointConfig#getDecoders()
	 */
	public List<Class<? extends Decoder>> getDecoders() {
		return new ArrayList<Class<? extends Decoder>>();
	}

	/* (non-Javadoc)
	 * @see javax.websocket.EndpointConfig#getEncoders()
	 */
	public List<Class<? extends Encoder>> getEncoders() {
		return new ArrayList<Class<? extends Encoder>>();
	}

	/* (non-Javadoc)
	 * @see javax.websocket.EndpointConfig#getUserProperties()
	 */
	public Map<String, Object> getUserProperties() {
		Map<String, Object> userProp = new HashMap<String, Object>();
		userProp.put("payload", this.payload);
		return userProp;
	}

	/* (non-Javadoc)
	 * @see javax.websocket.ClientEndpointConfig#getConfigurator()
	 */
	public Configurator getConfigurator() {
		return this;
	}

	/* (non-Javadoc)
	 * @see javax.websocket.ClientEndpointConfig#getExtensions()
	 */
	public List<Extension> getExtensions() {
		return new ArrayList<Extension>();
	}

	/* (non-Javadoc)
	 * @see javax.websocket.ClientEndpointConfig#getPreferredSubprotocols()
	 */
	public List<String> getPreferredSubprotocols() {
		return new ArrayList<String>();
	}
	
	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public long getTime() {
		return time;
	}
	
	/**
	 * Sets the time.
	 *
	 * @param time the time to set
	 */
	public void setTime(long time) {
		this.time = time;
	}

}
