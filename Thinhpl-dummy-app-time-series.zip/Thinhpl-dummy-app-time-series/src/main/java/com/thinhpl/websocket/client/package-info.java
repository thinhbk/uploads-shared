/**
 * 
 */
/**
 * @author ThinhPL
 *
 */
package com.thinhpl.websocket.client;