/**
 * 
 */
package com.thinhpl.websocket.client;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.websocket.ClientEndpointConfig;
import javax.websocket.ContainerProvider;
import javax.websocket.DeploymentException;
import javax.websocket.Endpoint;
import javax.websocket.MessageHandler;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.predix.timeseries.entity.datapoints.ingestionresponse.AcknowledgementMessage;
import com.predix.iot.wts.common.constants.Constants;
import com.predix.iot.wts.common.utils.UaaUtils;
import com.thinhpl.TmsConfig;
import com.thinhpl.UaaConfig;

/**
 * The Class TimeSeriesWebSocketClient.
 * 
 * @author ThinhPL
 */
@Component
public class TimeSeriesWebSocketClient {

	/** The Constant MAX_BINARY_BUFFER_SIZE. */
	private static final int MAX_BINARY_BUFFER_SIZE = 10000000;

	/** The logger. */
	private static Logger logger = Logger
			.getLogger(TimeSeriesWebSocketClient.class);

	/** The tms config. */
	@Autowired
	private TmsConfig tmsConfig;

	/** The uaa config. */
	@Autowired
	private UaaConfig uaaConfig;

	/** The web socket container. */
	private WebSocketContainer webSocketContainer = ContainerProvider
			.getWebSocketContainer();

	/** The sessions map. */
	Map<String, Session> sessionsMap = new HashMap<String, Session>();

	/** The token. */
	private String token;

	/**
	 * Send data via web socket.
	 * 
	 * @param url
	 *            the url
	 * @param data
	 *            the data
	 * @return true, if successful
	 */
	public synchronized boolean sendDataViaWebSocket(String url, String data) {
		Session session = sessionsMap.get("messages");
		if (session == null || !session.isOpen()) {
			Endpoint endpoint = new TimeSeriesEndpoint();
			List<Header> authHeaders = createAuthHeader();
			long time = Calendar.getInstance().getTimeInMillis();
			ClientEndpointConfig config = new TimeSeriesClientEndpointConfig(
					data, time, authHeaders);
			Session connectToServer = establishWebSocketConnection(endpoint,
					config);
			connectToServer.setMaxBinaryMessageBufferSize(MAX_BINARY_BUFFER_SIZE);
			sessionsMap.put("messages", connectToServer);
		}
		try {
			session = sessionsMap.get("messages");
			ByteBuffer byteBuffer = ByteBuffer.wrap(data.getBytes());
			session.getBasicRemote().sendBinary(byteBuffer);
			byteBuffer.flip();
//			System.out.println(data);
//			session.getBasicRemote().sendText(data);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * Establish connection via websocket.
	 *
	 * @param endpoint the endpoint
	 * @param config the config
	 * @return the session
	 */
	private Session establishWebSocketConnection(Endpoint endpoint,
			ClientEndpointConfig config) {
		Session connectToServer = null;
		try {
			connectToServer = webSocketContainer.connectToServer(endpoint,
					config, new URI(tmsConfig.getIngest_uri()));

			connectToServer
					.addMessageHandler(new MessageHandler.Whole<String>() {
						public void onMessage(String arg0) {
							logger.debug("Receive message from socket server: "
									+ arg0);
							if (arg0 == null) {
								logger.error("Receive msg with null body.");
							}
							ObjectMapper objectMapper = new ObjectMapper();
							try {
								AcknowledgementMessage readValue = objectMapper
										.readValue(arg0,
												AcknowledgementMessage.class);
								if (readValue.getStatusCode() >= 300) {
									logger.error("Error when trying to send data to websocket - msg: "
											+ readValue.getMessageId()
											+ ", code: "
											+ readValue.getStatusCode());
								}
							} catch (JsonParseException e) {
								e.printStackTrace();
							} catch (JsonMappingException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					});
		} catch (DeploymentException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (URISyntaxException e1) {
			e1.printStackTrace();
		}
		return connectToServer;
	}

	/**
	 * Creates the auth header.
	 * 
	 * @return the list
	 */
	private List<Header> createAuthHeader() {
		List<Header> headers = new ArrayList<Header>();
		if (token == null || token.isEmpty()) {
			token = getToken();
		}
		Header authorizationHeader = new BasicHeader(
				Constants.TS_AUTHORIZATION, Constants.TOKEN_BEARER + token);
		headers.add(authorizationHeader);
		Header predixZoneHeader = new BasicHeader(Constants.TS_PREDIX_ZONE_ID,
				tmsConfig.getInstanceId());
		headers.add(predixZoneHeader);
		Header originHeader = new BasicHeader(Constants.TS_ORIGIN,
				"http://localhost");
		headers.add(originHeader);
		Header contentTypeHeader = new BasicHeader(Constants.TS_CONTENT_TYPE,
				"application/json");
		headers.add(contentTypeHeader);
		return headers;
	}

	/**
	 * Gets the token.
	 * 
	 * @return the token
	 */
	private String getToken() {
		String token = UaaUtils.getAdminAccessToken(uaaConfig.getUri(),
				uaaConfig.getClientBase64Token());
		return token;
	}
}
