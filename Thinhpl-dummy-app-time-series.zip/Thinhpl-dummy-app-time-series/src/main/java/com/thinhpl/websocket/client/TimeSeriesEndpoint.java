/**
 * 
 */
package com.thinhpl.websocket.client;

import javax.websocket.CloseReason;
import javax.websocket.Endpoint;
import javax.websocket.EndpointConfig;
import javax.websocket.Session;

import org.apache.log4j.Logger;

/**
 * The Class TimeSeriesEndpoint.
 *
 * @author ThinhPL
 */
public class TimeSeriesEndpoint extends Endpoint {
	
	/** The logger. */
	private static Logger logger = Logger.getLogger(TimeSeriesEndpoint.class);

	/* (non-Javadoc)
	 * @see javax.websocket.Endpoint#onOpen(javax.websocket.Session, javax.websocket.EndpointConfig)
	 */
	@Override
	public void onOpen(Session arg0, EndpointConfig arg1) {
		logger.info("On Open session event");
	}

	@Override
	public void onClose(Session session1, CloseReason closereason)
    {
		logger.info("On Close session event");
    }

	@Override
    public void onError(Session session1, Throwable throwable1)
    {
		logger.info("On Close session event");
		logger.error(throwable1);
    }
}
