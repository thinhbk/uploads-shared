/**
 * 
 */
package com.thinhpl;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author ThinhPL
 *
 */
@Configuration
@ConfigurationProperties(prefix = "tms")
@EnableConfigurationProperties
public class TmsConfig {	
	
	private String query_uri;
	private String ingest_uri;
	private String instanceId;
	private String name;
	/**
	 * @return the query_uri
	 */
	public String getQuery_uri() {
		return query_uri;
	}
	/**
	 * @param query_uri the query_uri to set
	 */
	public void setQuery_uri(String query_uri) {
		this.query_uri = query_uri;
	}
	/**
	 * @return the ingest_uri
	 */
	public String getIngest_uri() {
		return ingest_uri;
	}
	/**
	 * @param ingest_uri the ingest_uri to set
	 */
	public void setIngest_uri(String ingest_uri) {
		this.ingest_uri = ingest_uri;
	}
	/**
	 * @return the instanceId
	 */
	public String getInstanceId() {
		return instanceId;
	}
	/**
	 * @param instanceId the instanceId to set
	 */
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
}
