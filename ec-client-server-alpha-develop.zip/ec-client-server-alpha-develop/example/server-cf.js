var RSServer=require('./../rs-server');
var http = require('http');
var httpProxy = require('http-proxy');
var _token='eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiJhMTU4YjliNWRlYWI0MTkzOTY1NWFmZjBhYmQ0NTI1MyIsInN1YiI6ImVjLWNsaWVudCIsInNjb3BlIjpbImFjcy5wb2xpY2llcy53cml0ZSIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy44NTgwNGVmZi0zMTAwLTRhOTAtYWE0Ni0zYTYwMmRhNzI5MjkudXNlciIsImFuYWx5dGljcy56b25lcy5kOGJiNDRmYy1kYWQzLTQ2YmYtOWIxMS05YzBkNTZjN2Q2MjkudXNlciIsInByZWRpeC1hc3NldC56b25lcy5hNGEwZjE3Yi05MmYyLTQ2MmYtOWE5Ny00MDc3MGE1ZDc1MGIudXNlciIsIm9wZW5pZCIsImFjcy5hdHRyaWJ1dGVzLndyaXRlIiwic2NpbS5yZWFkIiwidGltZXNlcmllcy56b25lcy4zODEzNGVjOC02ODU3LTQ1NTEtYjA3Yy0zZWU2MDM1MDc2ZWEudXNlciIsImFjcy5wb2xpY2llcy5yZWFkIiwicHJlZGl4LWFjcy56b25lcy44ODA2MDEwMC0wZGFkLTRmYTYtYjZhNC1iMjVjODUwNWZlMDEudXNlciIsImFjcy5hdHRyaWJ1dGVzLnJlYWQiLCJ0aW1lc2VyaWVzLnpvbmVzLjM4MTM0ZWM4LTY4NTctNDU1MS1iMDdjLTNlZTYwMzUwNzZlYS5xdWVyeSIsImFuYWx5dGljcy56b25lcy45N2U5NWU0OS1iODU0LTRhMzAtOGRlOC1kOWJlMzZjY2U0NGQudXNlciIsInRpbWVzZXJpZXMuem9uZXMuMzgxMzRlYzgtNjg1Ny00NTUxLWIwN2MtM2VlNjAzNTA3NmVhLmluZ2VzdCIsInNjaW0ud3JpdGUiXSwiY2xpZW50X2lkIjoiZWMtY2xpZW50IiwiY2lkIjoiZWMtY2xpZW50IiwiYXpwIjoiZWMtY2xpZW50IiwiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsInJldl9zaWciOiI2ZjA1NzBjNSIsImlhdCI6MTQ4MDY0NjkxOSwiZXhwIjoxNDgwNjkwMTE5LCJpc3MiOiJodHRwczovL2UzODgzYjg2LTBlM2EtNDJhYy05MDRmLTdjNWQ1NmRhNzA2YS5wcmVkaXgtdWFhLnJ1bi5hd3MtdXN3MDItcHIuaWNlLnByZWRpeC5pby9vYXV0aC90b2tlbiIsInppZCI6ImUzODgzYjg2LTBlM2EtNDJhYy05MDRmLTdjNWQ1NmRhNzA2YSIsImF1ZCI6WyJzY2ltIiwidGltZXNlcmllcy56b25lcy4zODEzNGVjOC02ODU3LTQ1NTEtYjA3Yy0zZWU2MDM1MDc2ZWEiLCJhY3MuYXR0cmlidXRlcyIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy44NTgwNGVmZi0zMTAwLTRhOTAtYWE0Ni0zYTYwMmRhNzI5MjkiLCJlYy1jbGllbnQiLCJvcGVuaWQiLCJwcmVkaXgtYXNzZXQuem9uZXMuYTRhMGYxN2ItOTJmMi00NjJmLTlhOTctNDA3NzBhNWQ3NTBiIiwicHJlZGl4LWFjcy56b25lcy44ODA2MDEwMC0wZGFkLTRmYTYtYjZhNC1iMjVjODUwNWZlMDEiLCJhY3MucG9saWNpZXMiLCJhbmFseXRpY3Muem9uZXMuZDhiYjQ0ZmMtZGFkMy00NmJmLTliMTEtOWMwZDU2YzdkNjI5IiwiYW5hbHl0aWNzLnpvbmVzLjk3ZTk1ZTQ5LWI4NTQtNGEzMC04ZGU4LWQ5YmUzNmNjZTQ0ZCJdfQ.dH5aQF3S01MTwV3nDFu0w7FRjGApL4-zAR9mAP1FYz2KU39_JhVDH7Yqv41guVyk0eoHNf_RcOaF6R44ZVs_ic0AIMqj_mHjqc32PwFISH0H98VkICQBZ235OSG-_29aA6Au8qlH6JnjlwXke2CaRq9nUfFeaQXSezmbP9z2B_55wFdrgFN7bqfOlH9AnL1M354-nuy2AryqvzG0ysQvwXVLR_tqyRXM7R3hs-OlHfBu1es_SiyVlYEABgv7ObZmbVrQyZNQh_cQisqQIXGYbCuVpK7hbHN6vV39heRGrC0ugAijXyMCYbpWeRwKSRlHpj9rcDYI0_716XPw6nTzOg';

//cf api
var cfapi=new RSServer({
    gatewayHost: 'wss://2348f618-b718-474c-b5e4-8ed884b6f00a.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'localhost', //no protocol prefix. this's always tcp
    resourcePort: process.env.PORT||0,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});


//cf login zoneid: cflogin-test
var cflogin=new RSServer({
    gatewayHost: 'wss://6a47376e-835a-4f50-b1d8-e724f28bf402.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'login.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});

//cf token zoneid: cftoken-test
var cftoken=new RSServer({
    gatewayHost: 'wss://2f060e3a-8c64-450e-95f2-6c027300653c.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'uaa.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});

//cf logger zoneid: cflogger-test
var cflogger=new RSServer({
    gatewayHost: 'wss://fc5e23d5-21b2-4d7e-9880-3ec20ef530af.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'loggregator.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});


//cf doppler zoneid: cfdoppler-test
var cfdoppler=new RSServer({
    gatewayHost: 'wss://8162bbed-ddb9-4550-8779-7833b07f8fb9.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.131.54.5', //no protocol prefix. this's always tcp
    resourceHost: 'doppler.system.asv-pr.ice.predix.io', //no protocol prefix. this's always tcp
    resourcePort: 443,
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
});

//command: DEBUG=rs:server node server

//project cf cli


var proxy = httpProxy.createProxyServer({});
//proxy.web(req, res, { target: 'http://mytarget.com:8080' });

//mock call to bypass the cf health check.

http.createServer((req, res)=>{
    if (req.url.indexOf("/v2/info")){
	res.writeHead(200);
	return res.end(JSON.stringify({
	    name:"",
	    build:"",
	    support:"http://support.cloudfoundry.com",
	    version:0,
	    description:"Cloud Foundry GE Open Sandbox",
	    "authorization_endpoint":"http://localhost:7991",
	    "token_endpoint":"http://localhost:7992",
	    "min_cli_version":null,
	    "min_recommended_cli_version":null,
	    "api_version":"2.62.0",
	    "app_ssh_endpoint":"ssh.system.asv-pr.ice.predix.io:2222",
	    "app_ssh_host_key_fingerprint":"a6:d1:08:0b:b0:cb:9b:5f:c4:ba:44:2a:97:26:19:8a",
	    "app_ssh_oauth_client":"ssh-proxy",
	    "logging_endpoint":"ws://localhost:7993",
	    "doppler_logging_endpoint":"ws://localhost:7994"}));
    }
    
    proxy.web(req, res, { target: 'https://api.system.asv-pr.ice.predix.io' });
    
}).listen(process.env.PORT||0, _=> {
    console.log(`${new Date()} CF healthcheck mockup call.`);
});
