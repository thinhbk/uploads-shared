var RSServer=require('./../rs-server');
var http = require('http');
var httpProxy = require('http-proxy');
var _token = 'eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI3MDkxNzM5NzViZDM0OTZlOWNiZjk4MzYwMTZkM2Y3ZCIsInN1YiI6ImVjLWNsaWVudCIsInNjb3BlIjpbImFjcy5wb2xpY2llcy53cml0ZSIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy44NTgwNGVmZi0zMTAwLTRhOTAtYWE0Ni0zYTYwMmRhNzI5MjkudXNlciIsImFuYWx5dGljcy56b25lcy5kOGJiNDRmYy1kYWQzLTQ2YmYtOWIxMS05YzBkNTZjN2Q2MjkudXNlciIsInByZWRpeC1hc3NldC56b25lcy5hNGEwZjE3Yi05MmYyLTQ2MmYtOWE5Ny00MDc3MGE1ZDc1MGIudXNlciIsIm9wZW5pZCIsImFjcy5hdHRyaWJ1dGVzLndyaXRlIiwic2NpbS5yZWFkIiwidGltZXNlcmllcy56b25lcy4zODEzNGVjOC02ODU3LTQ1NTEtYjA3Yy0zZWU2MDM1MDc2ZWEudXNlciIsImFjcy5wb2xpY2llcy5yZWFkIiwicHJlZGl4LWFjcy56b25lcy44ODA2MDEwMC0wZGFkLTRmYTYtYjZhNC1iMjVjODUwNWZlMDEudXNlciIsImFjcy5hdHRyaWJ1dGVzLnJlYWQiLCJ0aW1lc2VyaWVzLnpvbmVzLjM4MTM0ZWM4LTY4NTctNDU1MS1iMDdjLTNlZTYwMzUwNzZlYS5xdWVyeSIsImFuYWx5dGljcy56b25lcy45N2U5NWU0OS1iODU0LTRhMzAtOGRlOC1kOWJlMzZjY2U0NGQudXNlciIsInRpbWVzZXJpZXMuem9uZXMuMzgxMzRlYzgtNjg1Ny00NTUxLWIwN2MtM2VlNjAzNTA3NmVhLmluZ2VzdCIsInNjaW0ud3JpdGUiXSwiY2xpZW50X2lkIjoiZWMtY2xpZW50IiwiY2lkIjoiZWMtY2xpZW50IiwiYXpwIjoiZWMtY2xpZW50IiwiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsInJldl9zaWciOiI2ZjA1NzBjNSIsImlhdCI6MTQ4MDk5NzgwMywiZXhwIjoxNDgxMDQxMDAzLCJpc3MiOiJodHRwczovL2UzODgzYjg2LTBlM2EtNDJhYy05MDRmLTdjNWQ1NmRhNzA2YS5wcmVkaXgtdWFhLnJ1bi5hd3MtdXN3MDItcHIuaWNlLnByZWRpeC5pby9vYXV0aC90b2tlbiIsInppZCI6ImUzODgzYjg2LTBlM2EtNDJhYy05MDRmLTdjNWQ1NmRhNzA2YSIsImF1ZCI6WyJzY2ltIiwidGltZXNlcmllcy56b25lcy4zODEzNGVjOC02ODU3LTQ1NTEtYjA3Yy0zZWU2MDM1MDc2ZWEiLCJhY3MuYXR0cmlidXRlcyIsImVudGVycHJpc2UtY29ubmVjdC56b25lcy44NTgwNGVmZi0zMTAwLTRhOTAtYWE0Ni0zYTYwMmRhNzI5MjkiLCJlYy1jbGllbnQiLCJvcGVuaWQiLCJwcmVkaXgtYXNzZXQuem9uZXMuYTRhMGYxN2ItOTJmMi00NjJmLTlhOTctNDA3NzBhNWQ3NTBiIiwicHJlZGl4LWFjcy56b25lcy44ODA2MDEwMC0wZGFkLTRmYTYtYjZhNC1iMjVjODUwNWZlMDEiLCJhY3MucG9saWNpZXMiLCJhbmFseXRpY3Muem9uZXMuZDhiYjQ0ZmMtZGFkMy00NmJmLTliMTEtOWMwZDU2YzdkNjI5IiwiYW5hbHl0aWNzLnpvbmVzLjk3ZTk1ZTQ5LWI4NTQtNGEzMC04ZGU4LWQ5YmUzNmNjZTQ0ZCJdfQ.PKgfaRfug4PnN1hfrYuBbFvXla5cekaMgO_K3p7kzJGWXVbImyKGgFhQlPF7ztDZqwYe5o415mH3AYR1cblhnx77_z1Vqcv-NWJ3NjjAvwQJQL1CrCUvDHVrarwGpCjjNkUTJcwEwwC241ilOpWq5AYSTSOnVRQTpHjgLSw5gKJIAgvQ4KWlApkoqoWciCSjBMXfb266iSIdppmpRdYG-gsG-RnUXVctMJaHrwvtcQoysYpyF7xTqw4Z1lzCiztPLstnBlgh87VdyRncNhbc8RAronmaS5hE1APPNAENWKUjAu_NVu59noO7JocpuK0j_K8XNMvCTRvgW8TrZ6klHA';

var phs=new RSServer({
    //proxy service. remove _ to activate
    /*_proxy:{
	host:'proxy-src.research.ge.com',
	port:8080
    }, */
    _proxy:{
	host:'hcm-proxy',
	port:9090
    },
    gatewayHost: 'wss://85804eff-3100-4a90-aa46-3a602da72929.run.aws-usw02-pr.ice.predix.io',
    gatewayPort: 443,
    //gatewayHost: 'ws://localhost',
    //gatewayPort: 8989,
    //resourceHost: '10.72.6.143', //no protocol prefix. this's always tcp
    resourceHost: '10.88.102.47', //no protocol prefix. this's always tcp
    resourcePort: 5432, // This is for postgres db
    id: '191001', //Reachback service credential
    //secret: '1434344', //Presented if requested by gateway. This would be your the secret for the Basic auth
    oauthToken: _token
    });


//mock call to bypass the cf health check.

var proxy = httpProxy.createProxyServer({});

http.createServer((req, res)=>{
    console.log('req.url',req.url);
    res.writeHead(200);
    res.end();
    // proxy.web(req, res, {changeOrigin:true, target: 'https://api.system.aws-usw02-pr.ice.predix.io' });
}).listen(process.env.PORT||0, _=> {
    console.log(`${new Date()} CF healthcheck mockup call.`);
});

//command: DEBUG=rs:server node server
