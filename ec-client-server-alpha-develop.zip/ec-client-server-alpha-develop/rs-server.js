/*
 * author: chia.chang@ge.com
 */

'use strict';

//force setting for DEBUG env
process.env.DEBUG='rs:server';

const net=require('net');
const WebSocketClient = require('websocket').client;
const http = require('http');
const RSSession = require('./lib/session');
const tunnel = require('tunnel');

class RSServer extends RSSession {

    constructor(options){
	
	super(options);

	const debug=this.debug('rs:server');

	let pool=this._pool;
	
	let sockets=this._sockets;

	if (options.gatewayPort!="443"||options.gatewayHost.indexOf('wss://')!=0){
	    debug('${new Date} the gateway host/port config is not supported. host:${options.gatewayHost}, port:${options.gatewayPort}.');
	    return;
	}

	//create super channel
	let superconn=new WebSocketClient();

	superconn.on('connectFailed', (error)=> {
	    this._debug(`${new Date()} Super Connection Error: ${error.toString()}`);
	});
	
	superconn.on('connect', (cg) => {

	    cg.once('error', (error)=> {
		//debugger;
		this._debug(`${new Date()} gateway connection error: ${error.toString()}`);
	    });

	    cg.once('close', _=> {
		//debugger;
		this._debug(`${new Date()} gateway connection closed`);
		
	    });

	    cg.on('ping',(cancel, d)=>{

		if (!d||d.length==0)
		    return;
		
		let _d=JSON.parse(d);

		//debugger;

		switch (_d.msgType){

		case 'established':
		    if (_d.sessionId){

			let data=_d.sessionId;
			
			this._debug(`${new Date()} gateway connection{host=${options.gatewayHost},port=${options.gatewayPort}} established.`);
			
			this._debug(`${new Date()} session: ${data} established.`);
						
			let cr = net.connect(options.resourcePort, options.resourceHost, _ => {

			    
			    //60000 init keepalive value
			    cr.setKeepAlive(true, 60000);
			    
			    let _sId=data, v=this.fetchPendingCSocketInPool(_d.clientId);
			    
			    if (v){
				
				this._sockets.set(_sId,{gateway:v.client, resource:cr});
				
				this.pipeTwoWay(v.client,cr,_sId);
				
				this._debug(`${new Date()} resource connection{host=${options.resourceHost},port=${options.resourcePort}} established`);

				process.nextTick(() => {
				    this.emit('resource_connect', cr);
				});

				cg.ping(JSON.stringify({msgType:'established:acknowledge',sessionId:_sId}));
			    }
			    else {
				this._debug(`${new Date()} the server conection is forfeited due to the client ${_d.clientId} not found in queue.`);
			    }
			    //`connection to the gateway ${options.targetHost} has been established successfully.`);
			});
		    }
		    
		    break;
		    
		case 'standby':
		    this._debug(`${new Date()} server is standby for a client connection with session id: ${_d.sessionId}`);
		    break;
		    
		case 'request':
		    
		   // debugger;
		    
		    addServerInst().then((c)=>{

			c.on('error', (error)=> {
			    //debugger;
			    c.close();
			    this._debug(`${new Date()} gateway connection error: ${error.toString()}`);
			});

			c.on('close', _=> {
			    //debugger;
			    this._debug(`${new Date()} gateway connection closed`);
			});

			this._pool.push({id:_d.clientId,client:c});
			process.nextTick(() => {
			    this.emit('gateway_connect',c);
			});
		    });
		    
		    break;
		    
		default:
		    break;
		}
		
	    });

	    this._debug(`${new Date()} supper connection is established.`);
	    
	});
	
	let opts=JSON.parse(JSON.stringify(options));
	
	//specify the connection type
	opts.clientType='admin';

	//let _buf=new Buffer(opts.id+':'+opts.secret);

	//remove secret for secure handshake
	delete opts.secret;
	
	let _opt=new Buffer(JSON.stringify(opts));

	let _headers={
	    //'Authorization':'Basic '+_buf.toString('base64'),
	    'options':_opt.toString('base64')
	};

	let requestOpts=null;
	
	if (options.proxy){
	    let tunnelingAgent = tunnel.httpsOverHttp({
		proxy: options.proxy
	    });

	    requestOpts = {
		agent: tunnelingAgent
	    };
	}

	//debugger;
	superconn.connect(options.gatewayHost+':'+options.gatewayPort, null, null, _headers,requestOpts);
	
	let addServerInst=(oh)=>{

	    return new Promise((reso,reje)=>{

		//debugger;
		//dial in to the gateway
		let gateway = new WebSocketClient();

		gateway.on('connectFailed', (error)=> {
		    this._debug(`${new Date()} Connect Error: ${error.toString()}`);
		    
		    return reje(error);
		});

		gateway.on('connect', (cg) => {
		   //debugger;
		    return reso(cg);		    
		});

		//debugger;
		
		let opts=JSON.parse(JSON.stringify(options));

		//let _buf=new Buffer(opts.id+':'+opts.secret);

		//specify the connection type
		opts.clientType='server';

		//debugger;
		
		//remove for security
		delete opts.secret
		
		let _opt=new Buffer(JSON.stringify(opts));
		
		let _headers={
		    //'Authorization':'Basic '+_buf.toString('base64'),
		    'options':_opt.toString('base64'),
		};

		let requestOpts=null;
		
		if (options.proxy){
		    let tunnelingAgent = tunnel.httpsOverHttp({
			proxy: options.proxy
		    });

		    requestOpts = {
			agent: tunnelingAgent
		    };
		}

		//debugger;

		gateway.connect(options.gatewayHost+':'+options.gatewayPort, null, null, _headers,requestOpts);

	    }); 
	    
	};

    }

    fetchPendingCSocketInPool(cId){
	
	for (let idx=0,val=this._pool[idx];idx<this._pool.length;idx++) {

	    if (val.id===cId){
			
		//debugger;

		return this._pool.splice(idx,1)[0];
		//return this._pool[idx];
		
	    }
	}
	
	return false;

    }


        
}

//discard the self-signed cert error
//process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

module.exports=RSServer;
